
import pandas as pd
from tqdm import tqdm
import torch
from typing import List
import os
import numpy as np
import time
from ollama import Client
import random
import re


choices = ["A", "B", "C", "D"]
os.environ['HF_TOKEN'] = "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"
device = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

def format_example_mmlu(question, options, include_answer=True):
    prompt = question
    for j, option in enumerate(options):
        prompt += f"\n{choices[j]}. {option}"
    prompt += "\nAnswer:"
    return prompt

def gen_mmlu_prompt(data, subject, k=-1):
    prompt = f"The following are multiple choice questions (with answers) about {subject}.\n\n"
    if k == -1:
        k = len(data)
    for i in range(min(k, len(data))):
        question = data[i]['question']
        options = data[i]['choices']
        answer = data[i]["answer"]
        prompt += format_example_mmlu(question, options) + f" {choices[answer]}\n\n"
    return prompt

def format_example_mmlu_ollama(question: str, options: List[str], include_answer: True) -> str:
    prompt = f"Question: {question}\n\nOptions:\n"
    for j, option in enumerate(options):
        prompt += f"{j}: {option} ({choices[j]})\n"
    prompt += (
        "\nInstruction: Please answer by writing only the index number,(0, 1, 2, or 3) that matches the correct option. "
        "Do not add any other text or explanation.\n\n"
        "Correct Answer Format Example:\n"
        "If option 'A' is correct, respond with '0'.\n"
        "If option 'B' is correct, respond with '1'.\n"
        "If option 'C' is correct, respond with '2'.\n"
        "If option 'D' is correct, respond with '3'.\n\n"
        "Answer:"
    )
    return prompt

def gen_mmlu_prompt_ollama(data: List[dict], subject: str, k: int = -1) -> str:
    prompt = f"The following are multiple choice questions about {subject}.\n\n"
    if k == -1:
        k = len(data)
    for i in range(min(k, len(data))):
        question = data[i]['question']
        options = data[i]['choices']
        answer = data[i]["answer"]
        prompt += format_example_mmlu_ollama(question, options,include_answer=True)+ f" Correct Answer: {answer}\n\n"
    return prompt


def mmlu_evaluation(ntrain: int, subject: str, source: str, model=None, tokenizer=None, client: Client = None, test_data: List[dict] = None):
    cors = []
    char_correct = 0
    total_chars = 0
    skipped_questions = 0
    model_responses = []
    actual_answers = []

    if source == "huggingface":
        for i in tqdm(range(len(test_data)), desc=f"Evaluating {subject}"):
            prompt_end = format_example_mmlu(test_data[i]['question'], test_data[i]['choices'], include_answer=False)
            train_prompt = gen_mmlu_prompt(test_data, subject, ntrain)
            prompt = train_prompt + prompt_end
            inputs = tokenizer(prompt, return_tensors="pt").to(device)

            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=1,
                    do_sample=True,
                    temperature=0.1,
                    return_dict_in_generate=True,
                    output_scores=True
                )
            generated_response = tokenizer.decode(outputs.sequences[0][-1:], skip_special_tokens=True).strip()
            model_responses.append(generated_response)

            correct_answer = test_data[i]["answer"]
            actual_answers.append(correct_answer)
            cors.append(1 if generated_response == choices[correct_answer] else 0)
            char_correct += sum(1 for a, b in zip(generated_response, choices[correct_answer]) if a == b)
            total_chars += max(len(generated_response), len(choices[correct_answer]))

    elif source == "ollama":
        for i in tqdm(range(len(test_data)), desc=f"Evaluating {subject}"):
            if 'question' not in test_data[i] or 'choices' not in test_data[i] or 'answer' not in test_data[i]:
                print(f"Skipping invalid entry at index {i}: {test_data[i]}")
                skipped_questions += 1
                continue

            prompt_end = format_example_mmlu_ollama(test_data[i]['question'], test_data[i]['choices'], include_answer=False)
            train_prompt = gen_mmlu_prompt_ollama(test_data, subject, ntrain)
            prompt = train_prompt + prompt_end
            params = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
            }
            response = client.chat(**params)

            if 'message' in response and 'content' in response['message']:
                generated_response = response['message']['content'].strip()
            else:
                print(f"Invalid response format at index {i}: {response}")
                skipped_questions += 1
                continue

            match = re.search(r'\b[0-3]\b', generated_response)
            if match:
                generated_response = int(match.group())
            else:
                skipped_questions += 1
                continue

            correct_answer = test_data[i]["answer"]
            actual_answers.append(correct_answer)
            cors.append(1 if generated_response == correct_answer else 0)
            char_correct += sum(1 for a, b in zip(str(generated_response), str(correct_answer)) if a == b)
            total_chars += max(len(str(generated_response)), len(str(correct_answer)))

    else:
        raise ValueError("Invalid source specified. Choose either 'huggingface' or 'ollama'.")

    macro_acc = np.mean(cors) if cors else 0
    acc_char = char_correct / total_chars if total_chars > 0 else 0
    if subject == "all":
        total_acc = np.sum(cors) / len(cors) if len(cors) > 0 else 0
        print(f"Total Accuracy for all subjects: {total_acc:.3f}")
    print(f"Macro Average Accuracy: {macro_acc:.3f} - {subject}")
    print(f"Character Accuracy: {acc_char:.3f} - {subject}")
    print(f"Total Skipped Questions: {skipped_questions}")
    
    return macro_acc, acc_char



