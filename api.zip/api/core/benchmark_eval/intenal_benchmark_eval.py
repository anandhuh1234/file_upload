import pandas as pd
from tqdm import tqdm
import torch
from typing import List
import numpy as np
from ollama import Client
import random

choices = ["A", "B", "C", "D"]

SEED = 42
def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

def format_insurance(question: str, options: List[str], include_answer: True) -> str:
    prompt = f"Question: {question}\n\nOptions:\n"
    for j, option in enumerate(options):
        prompt += f"{j}: {option} ({choices[j]})\n"
    prompt += (
        "\nInstruction: Please answer by writing only the Letter,(A, B, C, or D) that matches the correct option. "
        "Do not add any other text or explanation.\n\n"
        "Answer:"
    )
    return prompt

def gen_insurance_prompt(data: pd.DataFrame, subject: str, k: int = -1) -> str:
    prompt = f"The following are multiple choice questions about {subject}.\n\n"
    if k == -1:
        k = len(data)
    for i in range(min(k, len(data))):
        row = data.iloc[i]  
        question = row['question']
        options = row['choices']
        answer = row["answer"]  
        
        prompt += format_insurance(question, options, include_answer=True) + f" Correct Answer: {answer}\n\n"
    return prompt

def internal_benchmark(ntrain: int, subject: str, source: str, model=None, tokenizer=None, client: Client = None, test_data: List[dict] = None):
    cors = []
    char_correct = 0
    total_chars = 0
    skipped_questions = 0
    model_responses = []
    actual_answers = []
    
    pad_token_id = tokenizer.pad_token_id if tokenizer else None

    if source == "huggingface":
        for i in tqdm(range(len(test_data)), desc=f"Evaluating {subject}"):
            row = test_data.iloc[i]  
            question = row['question']
            choices = row['choices']
            correct_answer_label = row['answer']

            prompt_end = format_insurance(question, choices, include_answer=False)
            train_prompt = gen_insurance_prompt(test_data, subject, ntrain)
            prompt = train_prompt + prompt_end
            inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=1,
                    do_sample=True,
                    temperature=0.1,
                    return_dict_in_generate=True,
                    pad_token_id=pad_token_id,
                    output_scores=True
                )
            generated_response = tokenizer.decode(outputs.sequences[0][-1:], skip_special_tokens=True).strip()
            model_responses.append(generated_response)
            
            print(f"Question {i+1}:")
            print(f"Actual Answer: {correct_answer_label}")
            print(f"Model Generated Response: {generated_response}\n")
            
            cors.append(1 if generated_response == correct_answer_label else 0)
            char_correct += sum(1 for a, b in zip(generated_response, correct_answer_label) if a == b)
            total_chars += max(len(generated_response), len(correct_answer_label))
        

    elif source == "ollama":
        print(f"Evaluating {subject} with Ollama model:")
        for i in tqdm(range(len(test_data)), desc=f"Evaluating {subject}"):
            row = test_data.iloc[i]  
            question = row['question']
            choices = row['choices']
            correct_answer_label = row['answer']

            prompt_end = format_insurance(question, choices, include_answer=False)
            train_prompt = gen_insurance_prompt(test_data, subject, ntrain)
            prompt = train_prompt + prompt_end
            params = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
            }
            response = client.chat(**params)

            if 'message' in response and 'content' in response['message']:
                generated_response = response['message']['content'].strip()
                model_responses.append(generated_response)  
            else:
                print(f"Invalid response format at index {i}: {response}", flush=True)
                skipped_questions += 1
                continue

    elif source == "openai":
        for i in tqdm(range(len(test_data)), desc=f"Evaluating {subject}"):
            row = test_data.iloc[i]  # Access the row using iloc
            question = row['question']
            choices = row['choices']
            correct_answer_label = row['answer']

            prompt_end = format_insurance(question, choices, include_answer=False)
            train_prompt =  gen_insurance_prompt(test_data, subject, ntrain)
            prompt = train_prompt + prompt_end
            try:
                response = client.completions.create(
                    model=model,
                    prompt=prompt,
                    temperature=0.1,
                    max_tokens=100,
                    top_p=0.5,
                    frequency_penalty=0,
                    presence_penalty=0,
                    best_of=1,
                    stop=None,
                    stream=False  
                )
                
                generated_response = response.choices[0].text.strip()
                print(f"Question: {question}")
                print(f"Generated Response: {generated_response}")
                model_responses.append(generated_response)
                correct_answer = correct_answer_label
                actual_answers.append(correct_answer)
                cors.append(1 if generated_response == choices[correct_answer] else 0)
                char_correct += sum(1 for a, b in zip(generated_response, choices[correct_answer]) if a == b)
                total_chars += max(len(generated_response), len(choices[correct_answer]))
            except Exception as e:
                print(f"An error occurred for question {question}: {e}")
                skipped_questions += 1                
            is_correct = (generated_response == correct_answer_label)
            cors.append(1 if is_correct else 0)           
            char_correct += sum(1 for a, b in zip(generated_response, correct_answer_label) if a == b)
            total_chars += max(len(generated_response), len(correct_answer_label))
        
    else:
        raise ValueError("Invalid source specified. Choose either 'huggingface' or 'ollama'.")

    macro_acc = np.mean(cors) if cors else 0
    acc_char = char_correct / total_chars if total_chars > 0 else 0
    
    
    print(f"Macro Average Accuracy: {macro_acc:.3f} - {subject}")
    print(f"Character Accuracy: {acc_char:.3f} - {subject}")
    print(f"Total Skipped Questions: {skipped_questions}")

    return macro_acc, acc_char
