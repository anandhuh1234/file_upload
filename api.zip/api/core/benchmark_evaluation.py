import os
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from .benchmark_eval.mmlu_eval import mmlu_evaluation
from .benchmark_eval.arc_challenge import arc_evaluation
from .benchmark_eval.intenal_benchmark_eval import internal_benchmark
from ollama import Client
from datasets import load_dataset


def load_huggingface_model(model_name):
    """Load a Hugging Face model and tokenizer."""
    print(f"Loading Hugging Face model: {model_name}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name).to("cuda" if torch.cuda.is_available() else "cpu")
    return model, tokenizer

def load_ollama_model(model_name, host_url):
    """Initialize an Ollama client for model evaluation."""
    print(f"Connecting to Ollama model: {model_name}")
    client = Client(host=host_url) 
    return client

def main(source, model_id, ntrain, subject, task):
    
    test_data_mmlu = load_dataset("lighteval/mmlu", subject, split="test") 
    test_data_arc = load_dataset("allenai/ai2_arc", "ARC-Challenge", split='test')  
    train_data_internal = load_dataset("Pitambar206/mcqu", split='train')

    if source == "huggingface":
        model, tokenizer = load_huggingface_model(model_id)
        if task == "mmlu":
            macro_acc, char_acc = mmlu_evaluation(ntrain=ntrain, subject=subject, source="huggingface", model=model, tokenizer=tokenizer, test_data=test_data_mmlu)
        elif task == "arc":
            macro_acc, char_acc = arc_evaluation(ntrain=ntrain, subject=subject, source="huggingface", model=model, tokenizer=tokenizer, test_data=test_data_arc)
        elif task == "internal":
            macro_acc, char_acc = internal_benchmark(ntrain=ntrain, subject=subject, source="huggingface", model=model, tokenizer=tokenizer, test_data=train_data_internal)
        del model
        del tokenizer

    elif source == "ollama":
        host_ip = os.getenv("OLLAMA_HOST_IP")
        host_port = os.getenv("OLLAMA_HOST_PORT")
        host_url = f'http://{host_ip}:{host_port}'
        client = load_ollama_model(model_id, host_url)
        if task == "mmlu":
            macro_acc, char_acc = mmlu_evaluation(ntrain=ntrain, subject=subject, source="ollama", model=model_id, client=client, test_data=test_data_mmlu)
        elif task == "arc":
            macro_acc, char_acc = arc_evaluation(ntrain=ntrain, subject=subject, source="ollama", model=model_id, client=client , test_data=test_data_arc)
        elif task=="internal":
            macro_acc, char_acc = internal_benchmark(ntrain=ntrain, subject=subject, source="ollama", model=model_id, client=client, test_data=train_data_internal)
    
    return macro_acc, char_acc
