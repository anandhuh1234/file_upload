
from typing import Dict, List
import os
import torch
import numpy as np
from typing import List
import re
from tqdm import tqdm
from ollama import Client

device = "cuda" if torch.cuda.is_available() else "cpu"

choices = ["A", "B", "C", "D"]

def format_example_arc(question: str, choices: Dict[str, List[str]]) -> str:
    """Format the question and options into a prompt."""
    formatted_input = f"Question: {question}\n"
    for label, text in zip(choices['label'], choices['text']):
        formatted_input += f"{label}. {text}\n"
    formatted_input += "Please choose the correct answer from the options above. Answer:"
    return formatted_input


def gen_arc_prompt(data, k=-1):
    """Generate the training prompt from the data."""
    prompt = "The following are multiple-choice questions (with answers).\n\n"
    if k == -1:
        k = len(data)
    for i in range(k):
        question = data[i]['question']
        options = data[i]['choices']
        answer = data[i]["answerKey"] 
        prompt += format_example_arc(question, options) + f"{answer}\n\n" 
    return prompt
def format_example_arc_ollama(question: str, choices: dict) -> str:
    formatted_input = f"Question: {question}\n"
    for label, text in zip(choices['label'], choices['text']):
        formatted_input += f"{label}. {text}\n"
    formatted_input += "Please choose the correct option from the list above. Provide only the letter corresponding to your answer (A, B, C, or D)."
    return formatted_input

def gen_arc_prompt_ollama(data: List[dict], k: int = -1) -> str:
    prompt = "The following are multiple-choice questions. For each question, provide only the correct answer's letter (A, B, C, or D).\n\n"
    if k == -1:
        k = len(data)
    for i in range(k):
        question = data[i]['question']
        options = data[i]['choices']
        prompt += format_example_arc_ollama(question, options) + "\n\n"
    return prompt

def arc_evaluation(ntrain: int, subject: str, source: str, model=None, tokenizer=None, client: Client = None, test_data: List[dict] = None):
    cors = []  
    char_correct = []
    model_responses = []  
    actual_answers = []
    correct_predictions=[]
    
    if source == "huggingface":
        for i in tqdm(range(len(test_data)), desc="Evaluating"):
            prompt_end = format_example_arc(test_data[i]['question'], test_data[i]['choices'])
            train_prompt = gen_arc_prompt(test_data, ntrain)
            prompt = train_prompt + prompt_end
            
            inputs = tokenizer(prompt, return_tensors="pt").to(device)
            with torch.no_grad():
                outputs = model.generate(**inputs, max_new_tokens=1, temperature=0.1, do_sample=True, return_dict_in_generate=True, pad_token_id=tokenizer.eos_token_id, output_scores=True)
                
            generated_sequences = outputs.sequences
            for seq in generated_sequences:
                generated_response = tokenizer.decode(seq, skip_special_tokens=True).strip()
                model_responses.append(generated_response)
                
                match = re.search(r'Answer:\s*([A-D])', generated_response)
                extracted_answer = match.group(1) if match else None
                correct_answer = test_data[i]["answerKey"]  
                actual_answers.append(correct_answer)
                
                # Evaluation logic
                cors.append(int(extracted_answer == correct_answer))
                if extracted_answer is not None and correct_answer is not None:
                    char_correct.append(int(extracted_answer == correct_answer))
                    
    elif source == "ollama": 
        for i in tqdm(range(len(test_data)), desc="Evaluating ARC"):
            prompt_end = format_example_arc_ollama(test_data[i]['question'], test_data[i]['choices'])
            train_prompt = gen_arc_prompt_ollama(test_data, ntrain)
            prompt = train_prompt + prompt_end
            
            params = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
            }
            response = client.chat(**params)
            
            if 'message' in response and 'content' in response['message']:
                generated_response = response['message']['content'].strip().upper()
            else:
                print(f"Invalid response format for index {i}. Skipping.")
                continue
            
            correct_answer = test_data[i]["answerKey"].upper()
            correct_predictions.append(generated_response == correct_answer)

    # Calculating metrics
    macro_acc = np.mean(cors) if cors else 0 
    print(f"Macro Average Accuracy: {macro_acc:.3f}")
    char_acc = np.mean(char_correct) if char_correct else 0
    print(f"Character Level Accuracy: {char_acc:.3f}")

    return macro_acc, char_acc
