import json
import os
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from base64 import b64encode, b64decode  # Import b64encode and b64decode


BLOCK_SIZE = 16
encryption_key = "b9c3125631629630b0d2ef7c96275937"

def hash_hmac(algo, data, key):
    h = hmac.HMAC(key, algo(), backend=default_backend())
    h.update(data)
    return h.finalize()

def chunk_split(data):
    LINELEN = 64
    chunks = [data[i:i + LINELEN] for i in range(0, len(data), LINELEN)]
    return b'\n'.join(chunks)

class EKlaim:
    def __init__(self, key):
        self.key = bytes.fromhex(key)

    def encrypt(self, raw):
        padding_len = BLOCK_SIZE - (len(raw) % BLOCK_SIZE)

        if isinstance(raw, str):
            padded_plaintext = raw.encode('utf-8') + bytes([padding_len] * padding_len)
        else:
            padded_plaintext = raw + bytes([padding_len] * padding_len)

        iv = os.urandom(BLOCK_SIZE)
        cipher = Cipher(algorithms.AES(self.key), modes.CFB(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(padded_plaintext) + encryptor.finalize()

        digest = hash_hmac(hashes.SHA256, ciphertext, self.key)
        signature = digest[:10]

        encoded = chunk_split(b64encode(signature + iv + ciphertext))
        return encoded

    def decrypt(self, enc):
        enc = enc.encode('utf-8')
        enc = enc.replace(b'----BEGIN ENCRYPTED DATA----\n', b'').replace(b'----END ENCRYPTED DATA----\n', b'')
        decoded = b64decode(enc)
        signature = decoded[:10]
        iv = decoded[10:BLOCK_SIZE + 10]

        cipher = Cipher(algorithms.AES(self.key), modes.CFB(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        ciphertext = decoded[BLOCK_SIZE + 10:]
        decrypted_padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

        padding_len = decrypted_padded_plaintext[-1]
        plaintext = decrypted_padded_plaintext[:-padding_len]

        return plaintext


def encrypt_entity(input):
    encrypted = EKlaim(encryption_key).encrypt(input).decode('utf-8')
    return encrypted

def decrypt_entity(input):
    decrypted = EKlaim(encryption_key).decrypt(input).decode('utf-8')
    return decrypted
