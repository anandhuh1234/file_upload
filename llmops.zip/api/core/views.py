import os
import re
import jwt
import uuid
import pytz
import json
import shutil
import pymongo
import subprocess
import aisuite as ai
from celery import shared_task
from django.utils import timezone
from django.http import JsonResponse, StreamingHttpResponse
from rest_framework.decorators import api_view
from django.views.decorators.csrf import csrf_exempt
from .benchmark_evaluation import main
from django.core.mail import EmailMessage

secret_key = "llmops"

def get_current_time():
    ist_timezone = pytz.timezone('Asia/Kolkata')
    current_time_utc = timezone.now()
    current_time_ist = current_time_utc.astimezone(ist_timezone)
    return current_time_ist

def connect_to_mongodb(uri='mongodb://localhost:27017/', db_name='llmops'):
    """
    Connect to MongoDB and return the database and client objects.
    
    Parameters:
        uri (str): MongoDB connection URI
        db_name (str): Name of the database to connect to
    
    Returns:
        db (Database): The MongoDB database object
        client (MongoClient): The MongoDB client object
    """
    client = pymongo.MongoClient(uri)
    db = client[db_name]
    return db, client

def insert_data(data, db, collection_name):
    """
    Insert a document into a specified collection in MongoDB.
    
    Parameters:
        data (dict): The document to insert.
        db (Database): The MongoDB database object.
        collection_name (str): The name of the collection to insert the document into.
        
    Returns:
        str: The ID of the inserted document if successful, or an error message.
    """
    collection = db[collection_name]
    collection.insert_one(data)

def update_data(collection:object, filter_field:str, filter_value:str, update_dict:dict):
    """
    Update documents in a specified collection based on filter criteria and update fields.
    
    Parameters:
        collection (str): Collection object
        filter_field (str): The field name to filter by
        filter_value (any): The value of the filter field to match documents
        update_dict (dict): A dictionary of key-value pairs to update in matched documents
    
    Returns:
        UpdateResult: Result of the update operation
    """
    filter_query = {filter_field: filter_value}
    update_query = {"$set": update_dict}

    # Perform the update
    result = collection.update_many(filter_query, update_query)
    return result

def get_user_details(token):
    user_data = {}
    try:
        db,client = connect_to_mongodb()
        collection = db['user_details']
        user_doc = collection.find_one({'user_token': token})
        if user_doc:
            user_data['name'] = user_doc.get('name')
            user_data['email'] = user_doc.get('email')
        else:
            print("No user found")
        client.close()
    except Exception as e:
        print(str(e))
    return user_data

@api_view(['POST'])
def delete_all_entries(request):
    data = json.loads(request.body)
    collection_name = data['collection_name']
    db, client = connect_to_mongodb()
    if collection_name not in db.list_collection_names():
        client.close()
        return JsonResponse({
            "status": False,
            "message": f"Collection '{collection_name}' does not exist."
        }, status=404)
    
    collection = db[collection_name] 
    document_count = collection.count_documents({})
    if document_count == 0:
        client.close()
        return JsonResponse({
            "status": False,
            "message": f"Collection '{collection_name}' is already empty."
        }, status=200)

    result = collection.delete_many({})

    client.close()

    return JsonResponse({
        "status": True,
        "message": "success",
        "deleted_count": result.deleted_count
    })

@api_view(['POST'])
def login(request):
    try:
        data = json.loads(request.body)
        email = data['email']
        password = data['password']
        payload = {
                "email": email,
                "password":password,
            }
        token = jwt.encode(payload, secret_key, algorithm='HS256')
        db,client = connect_to_mongodb()
        collection = db['user_details']
        user_doc = collection.find_one({'user_token': token})
        
        response = {}
        if user_doc:
            user_doc['_id']=str(user_doc['_id'])
            response['name'] = user_doc.get('name')
            response['email'] = user_doc.get('email')
            response['token']=token
            response["status"] = True
            response['user_role'] = user_doc.get('user_role')
            client.close()
            
            return JsonResponse(response, status=200)
        else:
            response["message"] = 'Please enter valid credentials'
            response['status'] = False

            return JsonResponse(response, status=200)
    except Exception as e:
        response_data = {"status": False, "message": f"Error: {str(e)}"}
        return JsonResponse(response_data, status=500)

@csrf_exempt 
@api_view(['POST'])
def signup(request):
    try:
        data = json.loads(request.body)
        db, client = connect_to_mongodb()
        user_details_collection = db['user_details']
        name = data['name']
        email = data['email']
        password = data['password']
        email_list = user_details_collection.distinct('email')

        if email in email_list:
            data = {"status": False, "message": "Email already exist."}
            client.close()
            return JsonResponse(data, status=500)
        else:
            payload = {
                "email": email,
                "password":password,
            }
            token = jwt.encode(payload, secret_key, algorithm='HS256')
            form_data = {
        
                    'name': name,
                    'email': email,
                    'password': password,
                    'user_token': token,
                    'user_role': "user",
            }
            
            user_details_collection.insert_one(form_data)
            client.close()
            return JsonResponse({"status": True, "message": "Register successfully"}, status=200)
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Failed: {str(e)}"}, status=500)

@api_view(['GET'])
def list_users(request):
    try:
        db, client = connect_to_mongodb()
        data = db['user_details'].find()
        user_list = list(data)
        client.close()

        for user in user_list:
            user.pop('_id', None)
            user.pop('password', None)
            user.pop('user_token', None)

        return JsonResponse({"status": True, "user_list": user_list}, status=200)
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {str(e)}"}, status=500)

@api_view(['POST'])
def remove_user(request):
    try:
        data = json.loads(request.body)
        email = data['email']
        db, client = connect_to_mongodb()
        
        # check if user exist
        collection = db['user_details']
        user = collection.find_one({'email': email})
        if not user:
            client.close()
            return JsonResponse({"status": False, "message": "Email does not exist"}, status=404)

        result = collection.delete_one({'email': email})
        client.close()
        if result.deleted_count == 1:
            return JsonResponse({"status": True, "message": f"User with email {email} has been removed successfully.", "email": email}, status=200)
        else:
            return JsonResponse({"status": False, "message": "Failed to remove the user. Please try again."}, status=500)
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {str(e)}"}, status=500)

@csrf_exempt 
@api_view(['POST'])
def update_user_role(request):
    try:
        data = json.loads(request.body)
        email = data['email']
        user_role = data['user_role']
        if user_role not in ['user', 'admin', 'superadmin']:
            return JsonResponse({"status": False, "message": "Please select one in ['user', 'admin', 'superadmin'] as user role"}, status=500)
        db, client = connect_to_mongodb()
        collection = db['user_details']
        user_data = list(collection.find())
        email_list = [user['email'] for user in user_data]
        if email in email_list:
            update_data(collection, 'email', email, {'user_role': user_role})
            client.close()
            return JsonResponse({"status": True, "message": "Role updated successfully"}, status=200)
        else:
            client.close()
            return JsonResponse({"status": False, "message": "Email does not exist"}, status=500)

    except Exception as e:
        return JsonResponse({"status": False, "message": f"Failed: {str(e)}"}, status=500)

@shared_task(name="_benchmark_evaluation", queue="benchmark_queue")
def _benchmark_evaluation(task_id, model_id, task, ntrain, source, subject, mail_alert, user_details):
    db, client = connect_to_mongodb()
    collection = db['benchmarks']
    # update status - in progress 
    collection.update_one(
        {"task_id": task_id},      # Filter to match the task_id
        {"$set": {"status": "In Progress"}}  # Update operation
    )
    status = "Failed"

    try:
        macro_acc, char_acc = main(source, model_id, ntrain, subject, task)
        status = "Completed"
        current_time_ist = get_current_time()
        completed_at = current_time_ist.strftime('%Y-%m-%d %H:%M:%S')
        collection.update_one(
            {"task_id": task_id},      
            {"$set": {"status": status, 
                    "completed_at": completed_at,
                    "score": macro_acc}}
        )
    except:
        collection.update_one(
        {"task_id": task_id},      # Filter to match the task_id
        {"$set": {"status": status}}  # Update operation
    )
    client.close()
    if mail_alert:
        name, email_id = user_details
        subject = 'Benchmark Evaluation Results'
        message = f'Greetings {name}, The benchmark evaluation has completed. \n\nBest regards, \n\nDeveloper Team'
        from_email = os.getenv('EMAIL_HOST_USER')
        recipient_list = [email_id]
        email = EmailMessage(subject, message, from_email, recipient_list)
        email.send()

@api_view(['POST'])
def benchmark_evaluation(request):
    try:
        data = json.loads(request.body)
        model_id = data['model_id']
        dataset = data['dataset']
        n_shot = data['n_shot']
        source = data['source']
        subject = data['subject']
        mail_alert = data["mail_alert"]
        token = data['token']
        user_details = get_user_details(token)
        name, email = "", ""
        if user_details:
            name = user_details['name']
            email = user_details['email']

        current_time_ist = get_current_time()
        task_id = str(uuid.uuid4()) # current_time_ist.strftime('%Y%m%d%H%M%S')
        initiated_at = current_time_ist.strftime('%Y-%m-%d %H:%M:%S')

        db, client = connect_to_mongodb()
        initial_data = {"task_id": task_id, 
                        "model_id": model_id, 
                        "dataset": dataset,
                        "subject": subject,
                        "n_shot": n_shot, 
                        "source": source, 
                        "initiated_at": initiated_at,
                        "status": "Pending",
                        "completed_at": "-",
                        "score": "-"}

        insert_data(initial_data, db, 'benchmarks')
        user_details = [name, email]
        client.close()
        _benchmark_evaluation.delay(task_id, model_id, dataset, n_shot, source, subject, mail_alert, user_details)
        return JsonResponse({"status": True,
                             "message": "success", 
                             "task_id": task_id,
                             "model_id": model_id, 
                             "dataset": dataset,
                             "subject": subject,
                             "n_shot": n_shot,
                             "source": source,
                             "initiated_at": initiated_at,
                             "status": "Pending",
                             "completed_at": "-",
                             "score": "-"})
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {str(e)}"}, status=500)

@api_view(['GET'])
def list_benchmark_data(request):
    try:
        db, client = connect_to_mongodb()
        data = db['benchmarks'].find()
        benchmarks_list = list(data)
        client.close()

        for benchmark in benchmarks_list:
            benchmark.pop('_id', None)

        return JsonResponse({"status": True, "benchmarks_list": benchmarks_list}, status=200)
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {str(e)}"}, status=500)

@api_view(['GET'])
def list_models(request):
    try:
        # db, client = connect_to_mongodb()
        # if 'models' not in db.list_collection_names():
        #     # all_models = {'ollama': [], 'huggingface': []}
        #     all_models = {'ollama': []}
        #     command = ['docker', 'exec', '-it', 'ollama', 'ollama', 'list']
        #     result = subprocess.run(command, capture_output=True, text=True)
        #     if result.returncode == 0:
        #         pattern = r"^(.*?)\s+"
        #         model_names = re.findall(pattern, result.stdout, re.MULTILINE)
        #         print(model_names)
        #         filtered_list = [element for element in model_names if element not in ['failed', 'NAME']]
        #         all_models['ollama'] = filtered_list

        #     # hf_cache_dir = os.path.expanduser("~/.cache/huggingface/hub")

        #     # if os.path.exists(hf_cache_dir):
        #     #     models = [d.replace("models--", "") for d in os.listdir(hf_cache_dir) if os.path.isdir(os.path.join(hf_cache_dir, d)) if d.startswith("models--")]
        #     #     llms = [model for model in models if not model.startswith(('sentence-transformers','cross-encoder'))]
        #     #     llms_filtered = [model.replace("--", "/") for model in llms if 'reranker' not in model and 'checkpoint' not in model]
        #     #     all_models['huggingface'] = llms_filtered
        #     # print(all_models)
        #     for source, models in all_models.items():
        #         for model in models:
        #             initial_data = { 
        #                     "model_id": model, 
        #                     "source": source, 
        #                     "status": "Completed",
        #                     }

        #             insert_data(initial_data, db, 'models')

        # data = db['models'].find()
        # models_list = list(data)
        # client.close()

        # for model in models_list:
        #     if model.get('_id', False):
        #         model.pop('_id', None)
        command = ['docker', 'exec', '-it', 'ollama', 'ollama', 'list']
        filtered_list = []
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            pattern = r"^(.*?)\s+"
            model_names = re.findall(pattern, result.stdout, re.MULTILINE)
            print(model_names)
            filtered_list = [element for element in model_names if element not in ['failed', 'NAME']]
        # return JsonResponse({"status": True, "models_list": models_list}, status=200)
        return JsonResponse({"status": True, "models_list": filtered_list}, status=200)
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {str(e)}"}, status=500)

@shared_task(name="_add_model", queue="model_ops_queue")
def _add_model(task_id, model_id, source):
    db, client = connect_to_mongodb()
    collection = db['models']
    # update status - in progress
    collection.update_one(
        {"task_id": task_id},      # Filter to match the task_id
        {"$set": {"status": "In Progress"}}  # Update operation
    )

    if source == 'ollama':
        # Construct the command to pull the model within the Docker container
        command = ['docker', 'exec', '-it', 'ollama', 'ollama', 'pull', model_id]
        
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            status = "Completed"
        else:
            status = "Failed"

        collection.update_one(
            {"task_id": task_id},      # Filter to match the task_id
            {"$set": {"status": status}}
            )
        client.close()
    elif source == "huggingface":
        pass

@api_view(['POST'])
def add_model(request):
    try:
        data = json.loads(request.body)
        model_id = data['model_id']
        source = data['source']
        db, client = connect_to_mongodb()
        task_id = str(uuid.uuid4())
        initial_data = { 
                        "task_id": task_id,
                        "model_id": model_id, 
                        "source": source, 
                        "status": "Pending",
                        }

        insert_data(initial_data, db, 'models')
        client.close()
        _add_model.delay(task_id, model_id, source)

        return JsonResponse({"status": True,
                             "message": f"Model {model_id} pulled successfully", 
                             "model_id": model_id,
                             "source": source,
                             "status": "Pending"
                             })
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {str(e)}"}, status=500)

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

@shared_task(name="_remove_model", queue="model_ops_queue")
def _remove_model(model_id, source):
    db, client = connect_to_mongodb()
    collection = db['models']
    if source == 'ollama':
        command = ['docker', 'exec', '-it', 'ollama', 'ollama', 'rm', model_id]
        
        # Execute the command
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            print(f'Model {model_id} removed successfully')
            collection.find_one_and_delete({"model_id": model_id})
        client.close()
    elif source== "huggingface":
        hf_cache_dir = os.path.expanduser("~/.cache/huggingface/hub")
        folder_path = f"models--{model_id.replace('/', '--')}"
        model_path = os.path.join(hf_cache_dir, folder_path)
        if os.path.exists(model_path):
            shutil.rmtree(model_path)
            print(f'Model {model_id} removed successfully')
            collection.find_one_and_delete({"model_id": model_id})
        client.close()
    else:
        client.close()
        print("Invalid source. Provide either ollama or huggingface")

@api_view(['POST'])
def remove_model(request):
    try:
        data = json.loads(request.body)
        model_id = data['model_id']
        source = data['source']
        _remove_model.delay(model_id, source)

        return JsonResponse({'status': 'success', 'message': f'Model {model_id} removed successfully'}, status=200)
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

