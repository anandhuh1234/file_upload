import streamlit as st
from time import sleep
from streamlit.runtime.scriptrunner import get_script_run_ctx
from streamlit.source_util import get_pages
from utils.ui import add_logo

def get_current_page_name():
    ctx = get_script_run_ctx()
    if ctx is None:
        raise RuntimeError("Couldn't get script context")

    pages = get_pages("")

    return pages[ctx.page_script_hash]["page_name"]


def make_sidebar():
    st.set_page_config(page_title="LLM Playground", page_icon="🤖", layout="wide")
    # sidebar width
    st.markdown(
        """
        <style>
            section[data-testid="stSidebar"] {
                width: 250px !important;
            }
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.logo("https://i.imgur.com/ldghDGN.png", size="large", link="https://www.techvantagesystems.com/")
    
    with st.sidebar:
        if st.session_state.get("logged_in", False):
            st.page_link("pages/inference.py", label="Inference", icon="✨")
            st.page_link("pages/benchmark.py", label="Benchmark", icon="📈")
            st.page_link("pages/config.py", label="Config", icon="🛠️")

            st.write("")
            st.write("")

            if st.button("Log out"):
                logout()

        elif get_current_page_name() != "streamlit_app":
            # If anyone tries to access a secret page without being logged in,
            # redirect them to the login page
            st.switch_page("streamlit_app.py")


def logout():
    st.session_state.logged_in = False
    st.info("Logged out successfully!")
    sleep(0.5)
    st.switch_page("streamlit_app.py")
