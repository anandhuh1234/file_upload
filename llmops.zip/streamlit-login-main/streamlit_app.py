import streamlit as st
from time import sleep
from navigation import make_sidebar
from utils.ui import remove_top_padding
from utils.api_handler import login, signup
make_sidebar()
remove_top_padding()

_, col, _ = st.columns([0.25, 0.5, 0.25])
col.markdown("""
        <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
                -webkit-background-clip: text;
                color: transparent;
                font-size: 3em;
                font-weight: bold;">
            LLM Playground
        </h1>
        """, unsafe_allow_html=True)

tab1, tab2 = col.tabs(["Login", "SignUp"])

with tab1:
    st.caption("Please log in to continue")
    username = st.text_input("Email")
    password = st.text_input("Password", type="password")

    if st.button("Log in", type="primary"):
        data = login(username, password)
        if data['status']:
            st.session_state.logged_in = True
            st.session_state.user_role = data['user_role']
            st.session_state.token = data['token']
            st.success("Logged in successfully!")
            sleep(1)
            st.switch_page("pages/inference.py")
        else:
            st.error(data['message'])

with tab2:
    st.caption("Sign Up")
    name = st.text_input("Name :red[*]")
    email = st.text_input("Email :red[*]")
    password = st.text_input("Password :red[*]", type="password")
    confirm_password = st.text_input("Confirm Password :red[*]", type="password")

    if st.button("Sign Up", use_container_width=True):
        if not name or not email or not password or not confirm_password:
            st.error("All fields are required.")
        elif password != confirm_password:
            st.error("Passwords do not match.")
        else:
            data = signup(name, email, password)
            if data['status']:
                st.success("Sign up successful!")
                st.toast("Please login to continue")
            else:
                st.error(data['message'])
            sleep(1)
            
