import os
from navigation import make_sidebar
from utils.ui import remove_top_padding
from utils.api_handler import upload_file, retrieve_content, list_models
import streamlit as st
from ollama import Client

make_sidebar()
remove_top_padding()

OLLAMA_HOST_URL = os.getenv("OLLAMA_HOST_URL")

@st.cache_resource()
def connect():
    client = Client(host=OLLAMA_HOST_URL)
    return client

# display model and hardware information
st.sidebar.write('---')
st.sidebar.title("Hardware Information")
st.sidebar.markdown("""
    - **GPU**: 8xTesla V100
    - **GPU Memory**: 132 GB
    - **vCPU**: 16
    - **RAM**: 480 GB
    - **Environment**: AWS
""")

st.sidebar.write('---')

with st.spinner("Connecting to server..."):
    try:
        client = connect()
    except Exception as e:
        st.error(f"Failed to connect to the server: {e}")

if 'model_selected' not in st.session_state:
    st.session_state.model_selected = ""

if 'rag_status' not in st.session_state:
    st.session_state.rag_status = False

if 'collection_name' not in st.session_state:
    st.session_state.collection_name = ""

if "messages" not in st.session_state:
    st.session_state.messages = []


def response_generator(messages, model_name):
    response = client.chat(
        model=model_name,
        messages=messages,
        options={"temperature": float(st.session_state.temperature), "num_ctx": int(st.session_state.max_tokens)},
        stream=True
    )
    for chunk in response:
        yield chunk['message']['content']

col1, col2 = st.columns([0.7, 0.2])

with col1:
    st.markdown("""
        <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
                -webkit-background-clip: text;
                color: transparent;
                font-size: 3em;
                font-weight: bold;">
            Model Inference
        </h1>
        """, unsafe_allow_html=True)
    st.caption(
        """
        **Note:** When you switch between different models, there may be an initial wait time as the model is being loaded. 
        However, once a model is loaded, subsequent inferences with the same model will not experience this delay.
        """)
    
    col3, col4 = st.columns([0.95, 0.05])
    refresh_button = col4.button("", icon=":material/refresh:", help="Refresh chat")
    if refresh_button:
        st.session_state.messages = []

    #  user input
    if prompt := col3.chat_input("Your message"):
        chat_container = st.container(height=500)
        with chat_container:
            placeholder = st.empty()
            if not st.session_state.model_selected == st.session_state.model_name:
                placeholder.write(":red[Loading the model...]")
                st.session_state.model_selected = st.session_state.model_name

            # display chat messages
            for message in st.session_state.messages:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])

            st.session_state.messages.append({"role": "user", "content": prompt})
            # display user message in chat message container
            with st.chat_message("user"):
                st.markdown(prompt)

            # display assistant response in chat message container
            with st.chat_message("assistant"):
                if st.session_state.rag_status:
                    retrieved_content = retrieve_content(prompt, st.session_state.collection_name).get("retrieved_content", "")
                    rag_prompt = f"""You are an assistant for question-answering tasks. Use the following pieces of retrieved context to answer the question. If you don't know the answer, just say that you don't know.

                    Question: {prompt}
                    Context: {retrieved_content} 
                    Answer: """

                    rag_message = [{"role": "user", "content": rag_prompt}]
                    response = st.write_stream(response_generator(rag_message, st.session_state.model_name))
                else:
                    response = st.write_stream(response_generator(st.session_state.messages, st.session_state.model_name))
            # add assistant response to chat history
            st.session_state.messages.append({"role": "assistant", "content": response})

with col2:
    model_container = st.container(border=True, height=700)
    with model_container:
        model_data = list_models()
        ollama_models = [model for model in model_data['models_list']]
        st.session_state.model_name = st.selectbox("Available models: ", ollama_models)
        st.session_state.temperature = st.slider(label="Temperature",min_value=0.0, max_value=2.0, value=0.1, step=0.05)
        st.session_state.max_tokens = st.slider(label="Max Tokens",min_value=32, max_value=4096, value=1024, step=32)
        st.session_state.rag_status = st.checkbox("**Enable RAG mode**", disabled=(st.session_state.model_name == '8B Instruct Finetuned (Insurance)'))

        if st.session_state.rag_status:
            # with st.expander("Add your documents to the DB"):
            uploaded_file = st.file_uploader("Upload PDF files", type='pdf')
            upload_button = st.button("Upload", key="upload_file")
            if upload_button and uploaded_file is not None:
                with st.spinner("Uploading in progress.."):
                    file_bytes = uploaded_file.read()
                    # Optional: Display file information
                    st.write(f"File name: {uploaded_file.name}")
                    response = upload_file(file_bytes)
                    print(response['collection_name'])
                    st.session_state.collection_name = response['collection_name']
                    st.write(response['message'])
                    if response['status']:
                        st.success("File uploaded successfully!")
                    else:
                        st.write(response.text)
