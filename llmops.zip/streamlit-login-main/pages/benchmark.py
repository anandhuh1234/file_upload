import numpy as np
from navigation import make_sidebar
from utils.ui import remove_top_padding
make_sidebar()
remove_top_padding()

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st
from datetime import datetime
from utils.api_handler import benchmark_evaluation, list_benchmark_data, list_models

subject_mapping = {
    "ARC": ['arc', 'None'],
    "Internal (Insurance)": ['internal', 'None'],
    "MMLU (All)": ["mmlu", "all"],
    "MMLU (Abstract Algebra)": ["mmlu", "abstract_algebra"],
    "MMLU (Anatomy)": ["mmlu", "anatomy"],
    "MMLU (Astronomy)": ["mmlu", "astronomy"],
    "MMLU (Business Ethics)": ["mmlu", "business_ethics"],
    "MMLU (Clinical Knowledge)": ["mmlu", "clinical_knowledge"],
    "MMLU (College Biology)": ["mmlu", "college_biology"],
    "MMLU (College Chemistry)": ["mmlu", "college_chemistry"],
    "MMLU (College Computer Science)": ["mmlu", "college_computer_science"],
    "MMLU (College Mathematics)": ["mmlu", "college_mathematics"],
    "MMLU (College Medicine)": ["mmlu", "college_medicine"],
    "MMLU (College Physics)": ["mmlu", "college_physics"],
    "MMLU (Computer Security)": ["mmlu", "computer_security"],
    "MMLU (Conceptual Physics)": ["mmlu", "conceptual_physics"],
    "MMLU (Econometrics)": ["mmlu", "econometrics"],
    "MMLU (Electrical Engineering)": ["mmlu", "electrical_engineering"],
    "MMLU (Elementary Mathematics)": ["mmlu", "elementary_mathematics"],
    "MMLU (Formal Logic)": ["mmlu", "formal_logic"],
    "MMLU (Global Facts)": ["mmlu", "global_facts"],
    "MMLU (High School Biology)": ["mmlu", "high_school_biology"],
    "MMLU (High School Chemistry)": ["mmlu", "high_school_chemistry"],
    "MMLU (High School Computer Science)": ["mmlu", "high_school_computer_science"],
    "MMLU (High School European History)": ["mmlu", "high_school_european_history"],
    "MMLU (High School Geography)": ["mmlu", "high_school_geography"],
    "MMLU (High School Government and Politics)": ["mmlu", "high_school_government_and_politics"],
    "MMLU (High School Macroeconomics)": ["mmlu", "high_school_macroeconomics"],
    "MMLU (High School Mathematics)": ["mmlu", "high_school_mathematics"],
    "MMLU (High School Microeconomics)": ["mmlu", "high_school_microeconomics"],
    "MMLU (High School Physics)": ["mmlu", "high_school_physics"],
    "MMLU (High School Psychology)": ["mmlu", "high_school_psychology"],
    "MMLU (High School Statistics)": ["mmlu", "high_school_statistics"],
    "MMLU (High School US History)": ["mmlu", "high_school_us_history"],
    "MMLU (High School World History)": ["mmlu", "high_school_world_history"],
    "MMLU (Human Aging)": ["mmlu", "human_aging"],
    "MMLU (Human Sexuality)": ["mmlu", "human_sexuality"],
    "MMLU (International Law)": ["mmlu", "international_law"],
    "MMLU (Jurisprudence)": ["mmlu", "jurisprudence"],
    "MMLU (Logical Fallacies)": ["mmlu", "logical_fallacies"],
    "MMLU (Machine Learning)": ["mmlu", "machine_learning"],
    "MMLU (Management)": ["mmlu", "management"],
    "MMLU (Marketing)": ["mmlu", "marketing"],
    "MMLU (Medical Genetics)": ["mmlu", "medical_genetics"],
    "MMLU (Miscellaneous)": ["mmlu", "miscellaneous"],
    "MMLU (Moral Disputes)": ["mmlu", "moral_disputes"],
    "MMLU (Moral Scenarios)": ["mmlu", "moral_scenarios"],
    "MMLU (Nutrition)": ["mmlu", "nutrition"],
    "MMLU (Philosophy)": ["mmlu", "philosophy"],
    "MMLU (Prehistory)": ["mmlu", "prehistory"],
    "MMLU (Professional Accounting)": ["mmlu", "professional_accounting"],
    "MMLU (Professional Law)": ["mmlu", "professional_law"],
    "MMLU (Professional Medicine)": ["mmlu", "professional_medicine"],
    "MMLU (Professional Psychology)": ["mmlu", "professional_psychology"],
    "MMLU (Public Relations)": ["mmlu", "public_relations"],
    "MMLU (Security Studies)": ["mmlu", "security_studies"],
    "MMLU (Sociology)": ["mmlu", "sociology"],
    "MMLU (US Foreign Policy)": ["mmlu", "us_foreign_policy"],
    "MMLU (Virology)": ["mmlu", "virology"],
    "MMLU (World Religions)": ["mmlu", "world_religions"]
}

# Page Layout
# st.title("Benchmark Evaluation")
st.markdown("""
    <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
            -webkit-background-clip: text;
            color: transparent;
            font-size: 3em;
            font-weight: bold;">
        Benchmark Evaluation
    </h1>
    """, unsafe_allow_html=True)

# Create two tabs: "Analytics Dashboard" and "Run Evaluation"
tab1, tab2 = st.tabs(["Analytics Dashboard", "Run Evaluation"])

# Tab 1: Analytics Dashboard for displaying historical benchmarks
with tab1:
    st.header("LLM Leaderboard 2024")

    @st.cache_data
    def leaderboard():
        # Define the data
        data = {
            "Model": [
                "Claude 3.5 Sonnet", "GPT-4o (0513)", "GPT-4 Turbo (0409)", "Llama 3.1 (405B)",
                "Mistral Large 2 (0724)", "Claude 3 Opus", "Llama 3.1 70B", "Gemini 1.5 Pro",
                "GPT-4 (0314)", "GPT-4o Mini", "Claude 3 Sonnet", "Gemini 1.5 Flash",
                "Claude 3 Haiku", "Llama 3.1 8B", "Mistral Nemo 12B"
            ],
            "Average": [
                "82.25%", "81.69%", "79.10%", "79.01%", "78.80%", "77.35%", "75.65%", "73.61%",
                "71.15%", "70.70%", "69.85%", "68.63%", "66.10%", "64.29%", "41.30%"
            ],
            "MMLU": [
                "88.70%", "88.70%", "86.50%", "88.60%", "84%", "86.80%", "86%", "81.90%",
                "86.40%", "82%", "79%", "78.90%", "75.20%", "73.0%", "68%"
            ],
            "GPQA": [
                "59.4%", "53.6%", "48.0%", "51.1%", "35.1%", "50.4%", "46.7%", "46.2%",
                "35.7%", "40.2%", "46.4%", "39.5%", "40.1%", "32.8%", "8.72%"
            ],
            "MMMU": [
                "68.3%", "69.1%", "63.1%", "64.5%", "—", "59.4%", "60.6%", "62.2%",
                "56.8%", "59.4%", "53.1%", "56.1%", "50.2%", "—", "—"
            ],
            "HellaSWAG": [
                "89%", "94.20%", "94.20%", "87%", "89.20%", "95.40%", "87%", "92.50%",
                "95.30%", "—", "89%", "81.30%", "85.90%", "74.20%", "83.5%"
            ],
            "HumanEval": [
                "92%", "90.20%", "90.20%", "89%", "92%", "84.90%", "80.50%", "71.90%",
                "67%", "87.20%", "73%", "67.50%", "75.90%", "72.60%", "—"
            ],
            "BBHard": [
                "93.10%", "91.30%", "87.60%", "81.3%", "87.30%", "86.80%", "81.30%", "84%",
                "83.10%", "—", "82.90%", "89.20%", "73.70%", "61%", "—"
            ],
            "GSM8K": [
                "96.40%", "89.80%", "91%", "96.80%", "93%", "95%", "95.10%", "91.70%",
                "92%", "—", "92.30%", "68.80%", "88.90%", "84.50%", "—"
            ],
            "MATH": [
                "71.10%", "76.60%", "72.20%", "73.80%", "71%", "60.10%", "68.0%", "58.50%",
                "52.90%", "70.20%", "43.10%", "67.70%", "38.90%", "51.90%", "5%"
            ]
        }

        # Create a DataFrame
        df = pd.DataFrame(data)
        for col in df.columns[1:]:  # Skip the 'Model' column
            df[col] = df[col].replace("—", np.nan)  # Replace '—' with NaN
            df[col] = df[col].str.rstrip('%').astype(float)  # Remove '%' and convert to float
        styled_df = df.style.highlight_max(axis=0, color="yellow", subset=df.columns[1:])  # Exclude "Model" from numeric columns
        
        # Display the table in Streamlit
        st.dataframe(styled_df, use_container_width=True, height=560)

        # Preprocess data
        for col in df.columns[1:]:  # Skip the 'Model' column
            df[col] = df[col].replace("—", np.nan)
    
            if df[col].dtype == 'object':
                df[col] = df[col].str.rstrip('%').astype(float)
            else:
                df[col] = pd.to_numeric(df[col], errors='coerce')

        tasks = ["Average", "MMLU", "GPQA", "MMMU", "HellaSWAG", "HumanEval", "BBHard", "GSM8K"]

        fig, axes = plt.subplots(2, 4, figsize=(20, 10))
        axes = axes.flatten()  # Flatten to iterate easily
        fig.suptitle("Score comparison", fontsize=24, fontweight='bold', color='#F4A300', y=1)
        fig.patch.set_facecolor('#1e1e2f')
        # Plot each task
        highlight_color = '#F4A300'  # Gold color from theme
        bar_color = '#2e3a47'  # Dark blue-gray color for bars
        grid_color = '#4e5b63'  # Subtle gray for grid lines
        title_font = {'fontsize': 18, 'color': '#F4A300'}

        # Plot each task
        for i, task in enumerate(tasks):
            ax = axes[i]
            
            top_4_models = df.sort_values(by=task, ascending=False).head(4)
            
            ax.set_facecolor('#2a2b38')  # Dark background for each plot

            # Plot the bar chart
            top_4_models.plot.bar(
                x="Model",
                y=task,
                ax=ax,
                legend=False,
                color=bar_color,
                edgecolor=highlight_color
            )
            
            ax.set_title(f"Best LLM in {task}", **title_font)
            ax.set_ylabel("Score", color='#F4A300')  # Light text color
            ax.set_xlabel("", color='#F4A300')  # Light text color
            
            # Add gridlines with subtle color
            ax.grid(True, axis='y', color=grid_color, linestyle='--', linewidth=0.5)
            
            # Rotate x-axis labels for better readability
            ax.set_xticklabels(top_4_models['Model'], rotation=45, ha='right', color='#F4A300')
            ax.tick_params(axis='y', colors='#F4A300')

        # Adjust layout
        plt.tight_layout()

        # Display the plot
        st.pyplot(fig)

    leaderboard()
# Tab 2: Run Evaluation for initiating a new benchmark task
with tab2:
    st.header("Run Test")
    if "admin" in st.session_state.user_role:
        col1, col2 = st.columns([0.7, 0.3])
        models_data = list_models()
        if models_data.get("status", False):
            model_source_dict = {model['model_id']:model['source']  for model in models_data["models_list"]}
            model_id_list = [model['model_id'] for model in models_data["models_list"]]
            model_id = col1.selectbox("Model ID :red[*]", options=model_id_list, index=None, placeholder="Select")
        else:
            model_id = col1.text_input("Model ID :red[*]", placeholder="Eg: meta-llama/Llama-3.1-8B or llama3.1:8b-instruct-fp16")
        benchmark = col1.selectbox('Select benchmark :red[*]', options=list(subject_mapping.keys()), index=None, placeholder="Select")
        n_shot = col1.number_input("N-shot :red[*]", min_value=0, max_value=25, value=0, step=5)
        # source = col1.selectbox('Select model source :red[*]', options=["huggingface", "ollama"], index=None, placeholder="Select")
        mail_alert = col1.checkbox("Email me when done", False)

        if col1.button("Run Benchmark"):
            if model_id and benchmark:
                source = model_source_dict[model_id]
                dataset, subject = subject_mapping[benchmark]

                payload = {
                    "model_id": model_id,
                    "dataset": dataset,
                    "n_shot": n_shot,
                    "source": source,
                    "subject": subject,
                    "mail_alert": mail_alert,
                    "token": st.session_state.get("token", "")
                }
                
                data = benchmark_evaluation(**payload)
                
                if data.get('status', False):
                    col1.success("Benchmark added to the queue.")
                else:
                    col1.error(data['message'])
            else:
                col1.warning("Please select required fields")

        st.subheader("Test Results")
        data = list_benchmark_data()
        if data.get('status', False):
            if len(data['benchmarks_list'])>0:
                df = pd.DataFrame(data['benchmarks_list'])
                # df = df.sort_values(by="status", ascending=False).drop_duplicates(subset=["model_id", "source"], keep="first")
                df = df[~(df["status"] == "Failed")]
                if len(df)>0:
                    df["initiated_at"] = pd.to_datetime(df["initiated_at"]).dt.strftime("%Y-%m-%d %H:%M:%S")
                    try:
                        df["completed_at"] = pd.to_datetime(df["completed_at"]).dt.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        pass
                    # Display the historical data in a table format
                    st.dataframe(df[["model_id", "dataset", "n_shot", "status", "completed_at", "score"]],
                                use_container_width=True)
                
                    st.write("")
                else:
                    st.info("No data available")
        else:
            st.info("Server is down")
    else:
        st.warning("You do not have permission to run benchmark. Please contact an administrator.")
