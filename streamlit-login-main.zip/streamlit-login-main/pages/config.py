from time import sleep
from navigation import make_sidebar
from utils.ui import remove_top_padding
make_sidebar()
remove_top_padding()
import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder
from utils.api_handler import list_models, list_users, add_model, remove_model, remove_user, update_user_role
from utils.agstyler import PINLEFT, PRECISION_TWO, draw_grid

if "user_role" not in st.session_state:
    st.session_state.user_role = "user"  # Example, change to "admin" as needed

# st.title("Model Configuration")
st.markdown("""
    <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
            -webkit-background-clip: text;
            color: transparent;
            font-size: 3em;
            font-weight: bold;">
        Server Configuration
    </h1>
    """, unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs(["Available Models", "Add Model", "Remove Model", 'User List'])
# tab1, tab2, tab3 = st.tabs(["Available Models", "Add Model", "Remove Model"])

# Tab 1: Available Models
with tab1:
    st.subheader("Available Models on Server")

    models_data = list_models()
    if models_data.get("status", False):
        models_list = models_data["models_list"]
        df = pd.DataFrame(models_list)
        st.dataframe(df[["model_id", "source", "status"]], use_container_width=True)
    else:
        st.error("Failed to fetch models list from the server.")

# Tab 2: Add Model
with tab2:
    st.subheader("Add a New Model")

    # Check if user has admin/superadmin role
    if "admin" in st.session_state.user_role:
        new_model_id = st.text_input("Model ID", placeholder="Enter Model ID, e.g., meta-llama/Llama-3.1-8B")
        new_model_source = st.selectbox("Source", ["huggingface", "ollama"])

        if st.button("Add Model"):
            response = add_model(model_id=new_model_id, source=new_model_source)
        
            if response.get("status", False):
                st.success(f"Model '{new_model_id}' download in queue.")
            else:
                st.error(f"Failed to add model '{new_model_id}'.")
    else:
        st.warning("You do not have permission to add models. Please contact an administrator.")

# Tab 3: Remove Model
with tab3:
    st.subheader("Remove an Existing Model")

    if "admin" in st.session_state.user_role:
        models_data = list_models()
        if models_data.get("status", False):
            models_list = models_data["models_list"]

            model_options = [f"{model['model_id']} ({model['source']})" for model in models_list]
            selected_model = st.selectbox("Select Model to Remove", model_options, index=None, placeholder="Select a model")
            remove_button = st.button("Remove Model")
            # Extract model_id and source from the selected option
            if remove_button:
                if selected_model:
                    model_id_to_remove, source_to_remove = selected_model.split(" (")
                    source_to_remove = source_to_remove.rstrip(")")

                    response = remove_model(model_id=model_id_to_remove, source=source_to_remove)
                    
                    if response.get("status", False):
                        st.success(f"Model '{model_id_to_remove}' removed successfully.")
                    else:
                        st.error(f"Failed to remove model '{model_id_to_remove}'.")
                else:
                    st.warning("Please select a model")
        else:
                st.info("No models available for removal.")
    else:
        st.warning("You do not have permission to remove models. Please contact an administrator.")

with tab4:
    st.subheader("Manage Users")
    if "superadmin" in st.session_state.user_role:
        st.caption("Select the checkbox to remove users or double-click on user roles to change their roles.")
        user_data = list_users()
        if user_data.get("status", False):
            user_list = user_data["user_list"]
            df = pd.DataFrame(user_list)
            df.sort_values('name', inplace=True)
            # grid_options = GridOptionsBuilder.from_dataframe(df)
            # dropdownlst = ['user', 'admin', 'superadmin']
            # grid_options.configure_column("user_role", editable=True, cellEditor='agSelectCellEditor', cellEditorParams={'values': dropdownlst })
            # # grid_options.build()
            # AgGrid(df, gridOptions=grid_options.build())
            roles = ['user', 'admin', 'superadmin']
            formatter = {
                'name': ('name', {'width': 100}),
                'email': ('email', {'width': 150}),
                'user_role': ('user_role', {
                    'editable': True,
                    'cellEditor': 'agSelectCellEditor',
                    'cellEditorParams': {
                        'values': roles
                    },
                    'width': 100
                    })
                }
            grid_table = draw_grid(df, formatter, fit_columns=True, theme='streamlit', use_checkbox=True, selection='multiple', auto_height=True)
            df_selected = grid_table['data']
            merged_df = pd.merge(df, df_selected, on='email', suffixes=('_original', '_updated'))
            
            # Find rows where 'user_role' has changed
            changed_roles_df = merged_df[merged_df['user_role_original'] != merged_df['user_role_updated']]
            changed_roles = dict(zip(changed_roles_df["email"], changed_roles_df["user_role_updated"]))
            if changed_roles:
                with st.popover('Update user roles'):
                    st.write("Confirm Role Change?")
                    change_role_button = st.button("Update")
                    if change_role_button:
                        for email, role in changed_roles.items():
                            update_user_role_response = update_user_role(email, role)
                            if update_user_role_response.get('message', False):
                                st.success(update_user_role_response['message'])
                        sleep(0.5)
                        st.rerun()
                        # st.rerun()         
            # remove users
            selected_row = grid_table["selected_rows"]
            if (selected_row is not None) and (len(selected_row) != 0):
                with st.popover('Remove Users'):
                    st.write("Do you want to remove the selected users?")
                    remove_user_button = st.button("Remove")
                    if remove_user_button:
                        st.write(type(selected_row), selected_row)
                        for email in selected_row['email']:
                            remove_user_response = remove_user(email)
                            if remove_user_response['message']:
                                st.toast(remove_user_response['message'])
                        sleep(0.5)
                        st.rerun()
                        st.success("Success")
            
        else:
            st.info('No users')
    else:
        st.warning("You do not have permission to access this page.")
