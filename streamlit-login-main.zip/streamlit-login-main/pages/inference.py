import os
from navigation import make_sidebar
from utils.ui import remove_top_padding
from utils.api_handler import upload_file
import streamlit as st
from ollama import Client

make_sidebar()
remove_top_padding()


OLLAMA_HOST_URL = os.getenv("OLLAMA_HOST_URL")

@st.cache_resource()
def connect():
    client = Client(host=OLLAMA_HOST_URL)
    return client

# Display model and hardware information
# st.sidebar.write('---')
st.sidebar.title("Hardware Information")
st.sidebar.markdown("""
    - **GPU**: 8xTesla V100
    - **GPU Memory**: 132 GB
    - **vCPU**: 16
    - **RAM**: 480 GB
    - **Environment**: AWS
""")

st.sidebar.write('---')

with st.spinner("Connecting to server..."):
    try:
        client = connect()
    except Exception as e:
        st.error(f"Failed to connect to the server: {e}")

if 'model_selected' not in st.session_state:
    st.session_state.model_selected = ""

if 'collection_name' not in st.session_state:
    st.session_state.collection_name = ""

if "messages" not in st.session_state:
    st.session_state.messages = []

model_dict = {
    '8B Instruct': 'llama3.1:8b-instruct-fp16',
    '70B Instruct 4bit': 'llama3.1:70b-instruct-q4_0',
    '70B Instruct 8bit': 'llama3.1:70b-instruct-q8_0',
    '8B Instruct (Insurance)': 'anandhuh/insuranceqa_v2',
    '70B Instruct 4bit (Insurance)': 'anandhuh/insuranceqa_70b_4bit'
}


def response_generator(messages, model_name):
    response = client.chat(
        model=model_dict[model_name],
        messages=messages,
        options={"temperature": float(st.session_state.temperature), "num_ctx": int(st.session_state.max_tokens)},
        stream=True
    )
    for chunk in response:
        yield chunk['message']['content']

col1, col2 = st.columns([0.7, 0.2])

with col1:
    st.markdown("""
        <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
                -webkit-background-clip: text;
                color: transparent;
                font-size: 3em;
                font-weight: bold;">
            Model Inference
        </h1>
        """, unsafe_allow_html=True)
    st.caption(
        """
        **Note:** When you switch between different models, there may be an initial wait time as the model is being loaded. 
        However, once a model is loaded, subsequent inferences with the same model will not experience this delay.
        """)
    
    col3, col4 = st.columns([0.95, 0.05])
    refresh_button = col4.button("", icon=":material/refresh:", help="Refresh chat")
    if refresh_button:
        st.session_state.messages = []
        # st.rerun()

    #  user input
    if prompt := col3.chat_input("Your message"):
        chat_container = st.container(height=500)
        with chat_container:
            placeholder = st.empty()
            if not st.session_state.model_selected == st.session_state.model_name:
                placeholder.write(":red[Loading the model...]")
                st.session_state.model_selected = st.session_state.model_name

            # display chat messages
            for message in st.session_state.messages:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])

            st.session_state.messages.append({"role": "user", "content": prompt})
            # display user message in chat message container
            with st.chat_message("user"):
                st.markdown(prompt)

            # display assistant response in chat message container
            with st.chat_message("assistant"):
                response = st.write_stream(response_generator(st.session_state.messages, st.session_state.model_name))
            # add assistant response to chat history
            st.session_state.messages.append({"role": "assistant", "content": response})

with col2:
    model_container = st.container(border=True, height=700)
    with model_container:
        st.session_state.model_name = st.selectbox("Available models: ", ('8B Instruct', '70B Instruct 4bit', '70B Instruct 8bit', '8B Instruct (Insurance)', '70B Instruct 4bit (Insurance)'))
        st.session_state.temperature = st.slider(label="Temperature",min_value=0.0, max_value=2.0, value=0.1, step=0.05)
        st.session_state.max_tokens = st.slider(label="Max Tokens",min_value=32, max_value=4096, value=1024, step=32)
        # st.session_state.rag_status = st.checkbox("**Enable RAG mode**", disabled=(st.session_state.model_name == '8B Instruct Finetuned (Insurance)'))
        
        # if st.session_state.rag_status:
        #     # with st.expander("Add your documents to the DB"):
        #     uploaded_file = st.file_uploader("Upload PDF files", type='pdf')
        #     upload_button = st.button("Upload", key="upload_file")
        #     if upload_button and uploaded_file is not None:
        #         with st.spinner("Uploading in progress.."):
        #             file_bytes = uploaded_file.read()
        #             # Optional: Display file information
        #             st.write(f"File name: {uploaded_file.name}")
        #             response = upload_file(file_bytes)
        #             st.session_state.collection_name = response['collection_name']
        #             st.write(response['message'])
        #             if response.status_code == 200:
        #                 st.success("File uploaded successfully!")
        #             else:
        #                 st.write(response.text)
        with st.expander('Hardware Information'):
            st.markdown("""
                - **GPU**: 8xTesla V100
                - **GPU Memory**: 132 GB
                - **vCPU**: 16
                - **RAM**: 480 GB
                - **Environment**: AWS
            """)
# # Input form
# col1, col2 = st.columns([0.7, 0.3])

# user_query = col1.text_area("Enter your query:")
# model_name = col2.selectbox("Available models: ", ('8B Instruct', '70B Instruct 4bit', '70B Instruct 8bit', '8B Instruct (Insurance)', '70B Instruct 4bit (Insurance)'))
# rag_status = col2.checkbox("**Enable RAG mode**", disabled=(model_name == '8B Instruct Finetuned (Insurance)'))
# if rag_status:
#     with st.sidebar.expander("Add your documents to the DB"):
#         uploaded_file = st.file_uploader("Upload PDF files", type='pdf')
#         if st.button("Upload") and uploaded_file is not None:
#             with st.spinner("Uploading in progress.."):
#                 file_bytes = uploaded_file.read()
#                 # Optional: Display file information
#                 st.write(f"File name: {uploaded_file.name}")
#                 files = {
#                     'file_data': file_bytes}
#                 api_url = f'http://{st.secrets["server"]["ip"]}:8090/upload_file'
#                 response = requests.post(api_url, files=files).json()
#                 st.session_state.collection_name = response['collection_name']

#                 st.write(response['message'])
#                 if response.status_code == 200:
#                     st.success("File uploaded successfully!")
#                 else:
#                     st.write(response.text)

# model_dict = {
#     '8B Instruct': 'llama3.1:8b-instruct-fp16',
#     '70B Instruct 4bit': 'llama3.1:70b-instruct-q4_0',
#     '70B Instruct 8bit': 'llama3.1:70b-instruct-q8_0',
#     '8B Instruct (Insurance)': 'anandhuh/insuranceqa_v2',
#     '70B Instruct 4bit (Insurance)': 'anandhuh/insuranceqa_70b_4bit'
# }

# def stream_data(messages, model_name):

#     stream = client.chat(
#         model=model_dict[model_name],
#         messages=messages,
#         options={"temperature": float(temperature), "num_ctx": int(max_tokens)},
#         stream=True,
#     )

#     for chunk in stream:
#         yield chunk['message']['content']

# if st.button("Submit", use_container_width=True):
#     if user_query:
#         placeholder = st.empty()
#         if not st.session_state.model_selected == model_name:
#             placeholder.write(":red[Loading the model...]")
#             st.session_state.model_selected = model_name
#         if rag_status:
#             api_url = f'http://{st.secrets["server"]["ip"]}:8090/retrieve_content'
#             data = json.dumps({"query": user_query, 'collection_name': st.session_state.collection_name})
#             response = requests.post(api_url, data=data).json()
#             retrieved_content = response['retrieved_content']
#             prompt = f"""You are an assistant for question-answering tasks. Use the following pieces of retrieved context to answer the question. If you don't know the answer, just say that you don't know.

#             Question: {user_query} 

#             Context: {retrieved_content} 

#             Answer: """
            
#             placeholder.write_stream(stream_data(prompt, model_name))
#         else:
#             messages=[{'role': 'user', 'content': user_query}]
#             placeholder.write_stream(stream_data(messages, model_name))
#     else:
#         st.warning("Please enter a question before submitting.")