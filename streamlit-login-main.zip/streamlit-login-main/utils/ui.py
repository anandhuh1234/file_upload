import streamlit as st

def add_logo():
    # Inject custom CSS to set the width of the sidebar
    st.markdown(
        """
        <style>
            section[data-testid="stSidebar"] {
                width: 250px !important; # Set the width to your desired value
            }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
        <style>
            [data-testid="stSidebarNav"] {
                background-image: url(https://i.imgur.com/ldghDGN.png);
                background-repeat: no-repeat;
                padding-top: 15px;
                background-position: 20px 30px;
                background-size: 180px 50px;
                
            }
    
        </style>
        """
       ,
        unsafe_allow_html=True,
    )

def remove_top_padding():
    st.markdown("""
        <style>
               .block-container {
                    padding-top: 2rem;
                    padding-bottom: 2rem;
                    padding-left: 2rem;
                    padding-right: 2rem;
                }
        </style>
        """, unsafe_allow_html=True)

