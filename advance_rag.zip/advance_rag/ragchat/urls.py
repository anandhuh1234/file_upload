from django.urls import path
from .views import *

urlpatterns = [
    path("upload_file", upload_file, name="upload_file"),
    path("list_uploaded_files", list_uploaded_files, name="list_uploaded_files"),
    path("delete_all_files", delete_all_files, name="delete_all_files"),
    path("retrieve_content", retrieve_content, name="retrieve_content"),
    path('delete-collections/', delete_all_collections, name='delete_all_collections')
]
