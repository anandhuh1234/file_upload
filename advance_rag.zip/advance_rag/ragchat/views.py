import os
import json
import numpy as np
from tqdm import tqdm
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import Chroma
from datetime import datetime
from langchain.text_splitter import RecursiveCharacterTextSplitter, SentenceTransformersTokenTextSplitter
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from nltk.corpus import stopwords
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema.document import Document
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from sentence_transformers import CrossEncoder
from PyPDF2 import PdfReader
import chromadb 
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction 

# Define the path where files will be temporarily stored before processing
TEMP_FILE_DIR = 'temp_files/'
os.makedirs(TEMP_FILE_DIR, exist_ok=True)

def _read_pdf(filename):
    reader = PdfReader(filename)
    pdf_texts = [p.extract_text().strip() for p in reader.pages]
    pdf_texts = [text for text in pdf_texts if text]
    return pdf_texts

def _chunk_texts(texts):
    character_splitter = RecursiveCharacterTextSplitter(
        separators=["\n\n", "\n", ". ", " ", ""],
        chunk_size=1000,
        chunk_overlap=200
    )
    character_split_texts = character_splitter.split_text('\n\n'.join(texts))
    token_splitter = SentenceTransformersTokenTextSplitter(chunk_overlap=200, tokens_per_chunk=256)
    token_split_texts = []
    for text in character_split_texts:
        token_split_texts += token_splitter.split_text(text)
    return token_split_texts

def load_chroma(filename, collection_name, embedding_function):
    texts = _read_pdf(filename)
    chunks = _chunk_texts(texts)
    chroma_client = chromadb.Client()
    chroma_collection = chroma_client.get_or_create_collection(name=collection_name, embedding_function=embedding_function)
    ids = [str(i) for i in range(len(chunks))]
    chroma_collection.add(ids=ids, documents=chunks)
    return chroma_collection

def word_wrap(string, n_chars=72):
    if len(string) < n_chars:
        return string
    else:
        return string[:n_chars].rsplit(' ', 1)[0] + '\n' + word_wrap(string[len(string[:n_chars].rsplit(' ', 1)[0])+1:], n_chars)

   
def project_embeddings(embeddings, umap_transform):
    umap_embeddings = np.empty((len(embeddings),2))
    for i, embedding in enumerate(tqdm(embeddings)): 
        umap_embeddings[i] = umap_transform.transform([embedding])
    return umap_embeddings

def augment_multiple_query(query):
    prompt_template = """You are a knowledgeable expert and research assistant. Your users are asking questions about a legal document. 
            Suggest up to five additional related questions to help them find the information they need for the provided question. 
            Suggest only short questions without compound sentences. Suggest a variety of questions that cover different aspects of the topic.
            Make sure they are complete questions, and that they are related to the original question.

            Original question: "{query}"
            
            (Output only the questions as a plain list without any introductory phrases, quotes, or numbers, each question on a new line.)

            """

    prompt = PromptTemplate.from_template(prompt_template)

    gemini_llm = ChatGoogleGenerativeAI(
        model="gemini-pro",
        verbose=True,
        temperature=0,
         google_api_key="AIzaSyAKYJ762LwTFZc8r_lyuMUJYiP8Rk9iV9k" 
    )

    llm_chain = LLMChain(llm=gemini_llm, prompt=prompt)
    response = llm_chain.run(query=query)
    content = response.split("\n")  
    return content

def query_and_retrieve_documents(collection_name, queries, embedding_function, n_results=10):
    chroma_client = chromadb.Client()
    chroma_collection = chroma_client.get_or_create_collection(name=collection_name, embedding_function=embedding_function)
    results = chroma_collection.query(query_texts=queries, n_results=n_results, include=['documents', 'embeddings'])
    retrieved_documents = results['documents'][0]
    return retrieved_documents


def re_rank_documents_with_cross_encoder(query, retrieved_documents):
    cross_encoder = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
    pairs = [[query, doc] for doc in retrieved_documents]  
    scores = cross_encoder.predict(pairs)
    ranked_indices = np.argsort(scores)[::-1][:5]
    ranked_documents = [retrieved_documents[idx] for idx in ranked_indices]
    return ranked_documents



 
def _retrieve_content(query: str, collection_name: str) -> str:  
    # Load the data collection
    embedding_function = SentenceTransformerEmbeddingFunction()

    questions = augment_multiple_query(query)
    queries = [query] + questions
    print("queries: ", queries)
    retrieved_documents = query_and_retrieve_documents(collection_name, queries, embedding_function,n_results=5)
    print("retrieved_documents: ", retrieved_documents)
    # if not retrieved_documents:
    #     retrieved_content = "Please upload a document to continue"
    #     return retrieved_content
    re_ranked_docs = re_rank_documents_with_cross_encoder(query, retrieved_documents)
    retrieved_content = ""
    for n, doc in enumerate(re_ranked_docs):
        content = f"{doc}\n"
        retrieved_content += content
    return retrieved_content

@csrf_exempt
def list_uploaded_files(request):
    if request.method == 'GET':
        try:
            if os.path.exists(TEMP_FILE_DIR):
                filenames = os.listdir(TEMP_FILE_DIR)
                files_only = [f for f in filenames if os.path.isfile(os.path.join(TEMP_FILE_DIR, f))]
                return JsonResponse({'files': files_only}, status=200)
            else:
                return JsonResponse({'files': []}, status=200)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
def delete_all_files(request):
    if request.method == 'POST':
        try:
            if os.path.exists(TEMP_FILE_DIR):
                filenames = os.listdir(TEMP_FILE_DIR)
                for f in filenames:
                    file_path = os.path.join(TEMP_FILE_DIR, f)
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                return JsonResponse({'message': 'All files deleted successfully'}, status=200)
            else:
                return JsonResponse({'error': 'Directory does not exist'}, status=404)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)
    
@csrf_exempt
def upload_file(request):
    if request.method == 'POST':
        uploaded_file = request.FILES.get('file_data')

        if not uploaded_file:
            return JsonResponse({'message': 'No file uploaded'}, status=400)

        file_path = os.path.join(TEMP_FILE_DIR, uploaded_file.name)
        default_storage.save(file_path, uploaded_file)  
        
        try:
            embedding_function = SentenceTransformerEmbeddingFunction()
            collection_name = datetime.now().strftime('%Y%m%d%H%M%S')
            vectorstore = load_chroma(file_path, collection_name, embedding_function)
            # vectorstore.persist()  
            return JsonResponse({'message': 'File processed and stored successfully in ChromaDB', 'collection_name': collection_name}, status=200)

        except Exception as e:
            return JsonResponse({'message': str(e)}, status=500)
    
    return JsonResponse({'message': 'Invalid request method'}, status=405)

@csrf_exempt
def retrieve_content(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        query = data.get("query", '')
        collection_name = data.get("collection_name", '')

        chroma_client = chromadb.Client()
        collections = chroma_client.list_collections()
        # Loop through all collections and delete them
        collection_names = [collection.name for collection in collections]
        if collection_name not in collection_names:
            return JsonResponse({'message': 'Please upload a document to continue'}, status=400)
        answer = _retrieve_content(query, collection_name)  # Pass the full file path
        return JsonResponse({'message': 'success', 'retrieved_content': answer}, status=200)

    return JsonResponse({'message': 'Invalid request method'}, status=405)


@csrf_exempt
def delete_all_collections(request):
    if request.method == 'POST':
        try:
            # Create a ChromaDB client
            chroma_client = chromadb.Client()
            # Get the list of all collections
            collections = chroma_client.list_collections()
            # Loop through all collections and delete them
            for collection in collections:
                collection_name = collection.name
                chroma_client.delete_collection(collection_name)
            
            return JsonResponse({'message': 'All collections deleted successfully'}, status=200)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method. Use DELETE.'}, status=405)

